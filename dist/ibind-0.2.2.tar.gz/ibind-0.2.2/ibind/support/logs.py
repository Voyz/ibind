import datetime
import logging
import os.path
import re
import sys
from pathlib import Path
from typing import List

from ibind import var

DEFAULT_FORMAT = '%(asctime)s|%(levelname)-.1s| %(message)s'

_initialized = False
_log_to_file = False


def get_logger_children(main_logger) -> List[logging.Logger]:
    """
    Gets child loggers. Added as a support compat for Python version 3.11 and below.
    Source: https://github.com/python/cpython/blob/3.12/Lib/logging/__init__.py#L1831
    """
    if hasattr(main_logger, 'getChildren'):
        return list(main_logger.getChildren())

    def _hierlevel(logger):
        if logger is logger.manager.root:
            return 0
        return 1 + logger.name.count('.')

    d = main_logger.manager.loggerDict
    return [
        item
        for item in d.values()
        if isinstance(item, logging.Logger) and item.parent is main_logger and _hierlevel(item) == 1 + _hierlevel(item.parent)
    ]


def project_logger(filepath=None):
    """
    Returns a project-specific logger instance.

    This function creates a new logger instance with the name `'ibind'.{filepath.stem}` if `filepath` is specified,
    or 'ibind' if `filepath` is not specified.

    Parameters:
        filepath (str): The file path where the log files will be stored. If no filepath is specified, the default logs directory will be used.

    Returns:
        logging.Logger: The project-specific logger instance.
    """
    logger_name = 'ibind'
    if filepath is not None:
        child = Path(filepath).stem if os.path.exists(filepath) else str(filepath)
        logger_name += f'.{child}'

    return logging.getLogger(logger_name)


# IBKR account ids: `U`, `DU`, `DF` or `DFP` followed by digits. Lookarounds rather than `\b`, so that
# ids preceded by an underscore (e.g. the `ibkr_client_<id>` log file path) are matched too.
_ACCOUNT_ID_RE = re.compile(r'(?<![A-Za-z0-9])(U|D[UF]P?)(\d{6,10})(?![0-9])')


def mask_account_ids(text) -> str:
    """Masks every account id found in `text`, such as in URLs, request parameters or response payloads."""
    return _ACCOUNT_ID_RE.sub(lambda m: f'{m.group(1)}***{m.group(2)[-4:]}', str(text))


class AccountIdMaskingFormatter(logging.Formatter):
    """
    Formatter that masks account ids in the final log output, including exception tracebacks.

    Used by IBind's built-in console and file handlers. Apply it to your own handlers receiving IBind logs to mask
    account ids there too. Masking can be disabled with the `IBIND_MASK_ACCOUNT_IDS` environment variable.
    """

    def format(self, record):
        text = super().format(record)
        return mask_account_ids(text) if var.MASK_ACCOUNT_IDS else text


_LOGGER = project_logger()


def ibind_logs_initialize(
    log_to_console: bool = var.LOG_TO_CONSOLE,
    log_to_file: bool = var.LOG_TO_FILE,
    log_level: str = var.LOG_LEVEL,
    log_format: str = var.LOG_FORMAT,
    print_file_logs: bool = var.PRINT_FILE_LOGS,
):
    """
    Initialises the logging system.

    Parameters:
        log_to_console (bool): Whether the logs should be output to the current console, `True` by default
        log_to_file (bool): Whether the logs should be written to a daily log file, `True` by default.
        log_level (str): What is the minimum log level of `ibind` logs, `INFO` by default.
        log_format (str): What is the log format to be used, `'%(asctime)s|%(levelname)-.1s| %(message)s'` by default.

    Note:
        - All of these parameters are read from the environment variables by default.
        - The daily file logs are saved in the directory specified by the `IBIND_LOGS_DIR` environment variable, the system temp directory by default.
        - To get more verbose logs, set either the `log_level` parameter or the `IBIND_LOG_LEVEL` environment variable to `'DEBUG'`
    """
    global _initialized
    if _initialized:
        return
    _initialized = True

    global _log_to_file
    _log_to_file = log_to_file

    logger = logging.getLogger('ibind')
    formatter = AccountIdMaskingFormatter(log_format, datefmt='%H:%M:%S')
    logger.setLevel(logging.DEBUG)

    h1 = logging.StreamHandler(stream=sys.stdout)
    if log_to_console:
        # outputting only to a single stream to ensure chronological ordering of all messages
        h1.setLevel(getattr(logging, log_level))
        h1.setFormatter(formatter)
        logger.addHandler(h1)

    if not _log_to_file:
        logging.getLogger('ibind_fh').addFilter(lambda record: False)
    elif print_file_logs:
        logging.getLogger('ibind_fh').addHandler(h1)


def new_daily_rotating_file_handler(logger_name, filepath):
    """
    Creates and configures a new daily rotating file handler for logging.

    This function sets up a file-based logger with a daily rotation. It ensures that each day's logs are
    saved in a separate file. The logger is configured with a specific name and file path. If the logger
    with the given name doesn't already have handlers, it adds a new daily rotating file handler to it.

    Parameters:
        logger_name (str): The name to be assigned to the logger. This name is used to identify the logger instance.
        filepath (str): The file path where the log files will be stored. This path determines the location of the log files.

    Returns:
        logging.Logger: The logger configured with the daily rotating file handler.

    Note:
        - The logger is set to DEBUG level by default.
        - The format of the logs is determined by the DEFAULT_FORMAT global variable.
    """
    logger = logging.getLogger(f'ibind_fh.{logger_name}')

    if _log_to_file:
        ibind_filehandler = None
        for handler in logger.handlers:
            if isinstance(handler, DailyRotatingFileHandler) and handler.name == logger_name:
                ibind_filehandler = handler
                break

        if ibind_filehandler is None:
            _LOGGER.info(f'New daily rotating file handler for logger "{logger_name}": {filepath}')
            fh_logger = logging.getLogger('ibind_fh')
            handler = DailyRotatingFileHandler(filename=filepath, encoding='utf-8')
            handler.name = logger_name
            handler.setFormatter(AccountIdMaskingFormatter(DEFAULT_FORMAT))

            # if filehandler outputs are disabled, this should bring over the filter that will do this
            for filter in fh_logger.filters:
                logger.addFilter(filter)
            logger.addHandler(handler)
        else:
            _LOGGER.info(f'Existing daily rotating file handler for logger "{logger_name}": {filepath}')

        logger.setLevel(logging.DEBUG)
    else:
        logger.addHandler(logging.NullHandler())

    return logger


class DailyRotatingFileHandler(logging.FileHandler):
    def __init__(self, *args, date_format='%Y-%m-%d', **kwargs):
        self.timestamp = None
        self.date_format = date_format
        self.stream = None
        super().__init__(*args, **kwargs)

    def get_timestamp(self):
        now = datetime.datetime.now(datetime.timezone.utc)
        return now.strftime(self.date_format)

    def get_filename(self, timestamp):
        return f'{self.baseFilename}__{timestamp}.txt'

    def _open(self):
        if self.stream is not None:
            self.close()
        self.timestamp = self.get_timestamp()
        filename = self.get_filename(self.timestamp)
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        return open(filename, self.mode, encoding='utf-8')

    def emit(self, record):
        if self.get_timestamp() != self.timestamp:
            self.close()
            self.stream = self._open()

        super().emit(record)
